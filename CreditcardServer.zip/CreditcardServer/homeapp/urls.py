from django.urls import path
from . import views


urlpatterns = [
	path('',views.Login,name='Login'),
        path('register/',views.register,name='register'),
        path('logout_page/',views.logout_page,name='logout_page'),
         path('home/',views.home,name='home'),
         path('detail/',views.detail,name='detail'),
         
]
