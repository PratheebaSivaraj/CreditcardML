from django.contrib import admin

from .models import StoreImages
admin.site.register(StoreImages)