from django.db import models
class StoreImages(models.Model):
    imgname=models.CharField(max_length=50,default="emp")
    data=models.ImageField(upload_to ="img/")
    
